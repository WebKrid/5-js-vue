const vue = new Vue({
   el: "#app",
    data:{
       name: 'работа',
    },
    methods: {
      searchLine(){
         this.searchLine = searchLine,
       }
    },
    FilterGoods(){
      render() { return()
       `<div class="right-block">
       <p class="product-price">${this.quantity*this.price}</p>
       <button class="del-btn" data-id="${this.id_product}">&times;</button>
       </div>`
   }};
         },
         isVisibleCart(){
   
    },
});
